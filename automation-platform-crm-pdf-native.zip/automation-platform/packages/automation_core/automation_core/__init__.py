"""Shared automation platform primitives."""

